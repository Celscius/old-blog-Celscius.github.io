const $tree = $("#tree1");

$tree.tree({
    autoOpen: 0,
    data: ExampleData.exampleData,
    dragAndDrop: true,
});
