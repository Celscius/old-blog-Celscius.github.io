module.exports = {
    projects: [
        "<rootDir>/jest-browser.config.js",
        "<rootDir>/jest-jsdom.config.js",
    ],
    coverageDirectory: "jest-coverage",
    coverageReporters: ["json"],
};
