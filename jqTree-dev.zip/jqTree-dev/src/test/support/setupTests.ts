import * as jQuery from "jquery";
import "./jqTreeMatchers";

(window as any).jQuery = jQuery; // eslint-disable-line @typescript-eslint/no-unsafe-member-access
