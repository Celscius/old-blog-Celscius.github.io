---
title: moveDown
name: functions-movedown
---

**function moveDown()**

Select the next node. This does the same as the *down* key.