---
title: tree.refresh
name: event-tree-refresh
---

The `tree.refresh` event is triggered when the tree is repainted.

Examples when the `tree.refresh` event is fired:

-   after the first draw of the tree
-   after a node is moved
-   after the `updateNode` method is called
