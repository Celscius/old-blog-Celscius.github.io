<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Selected</title>
</head>
<body>
<p>You Selected <?=$_REQUEST['selected']?></p>
</body>
</html>