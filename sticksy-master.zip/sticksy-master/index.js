// For node support
module.exports = require('./src/sticksy')